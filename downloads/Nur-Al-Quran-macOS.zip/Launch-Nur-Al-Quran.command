#!/bin/bash
cd "$(dirname "$0")"
open -a "Google Chrome" --args --app="file://$(pwd)/index.html" 2>/dev/null || open "file://$(pwd)/index.html"
