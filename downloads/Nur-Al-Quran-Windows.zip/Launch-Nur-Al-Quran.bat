@echo off
title Nur-ul-Quran (??? ??????)
echo ========================================================
echo   Nur-ul-Quran (??? ??????) - 15 Line Offline Mushaf
echo ========================================================
echo Starting standalone offline app...
where chrome.exe >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" chrome.exe --app="file://%~dp0index.html"
) else (
    where msedge.exe >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        start "" msedge.exe --app="file://%~dp0index.html"
    ) else (
        start "" "%~dp0index.html"
    )
)
exit
